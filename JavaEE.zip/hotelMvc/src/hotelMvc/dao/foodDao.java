package hotelMvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import hotelMvc.domain.Food;
import hotelMvc.JDBCutils.JDBCutils;

public class foodDao {
	private Map<String,Food> foods = new HashMap<>();
	private Map<String,Food> foods1 = new HashMap<>();
	
	public boolean addFood(String foodName, String foodVip) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "insert into food values(0,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, foodName);
			ps.setString(2,foodVip);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	public boolean deleteFood(int foodId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "delete from food where foodId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,foodId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	public boolean updateFood(int foodId, String foodName, String foodVip) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "update room set foodName=?,foodVip=? where foodId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, foodName);
			ps.setString(2, foodVip);
			ps.setInt(3,foodId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	public Map<String, Food> getFood() throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String sql = "select * from food";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			String foodId = rs.getString("foodId");
			String foodName = rs.getString("foodName");
			String foodVip = rs.getString("foodVip");
			Food food = new Food(foodId, foodName, foodVip);
			foods.put(foodId, food);
		}
		return foods;
	}
	
	public Map<String, Food> getFoodList(String vip) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String sql = "select * from food where foodVip = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, vip);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			String foodId = rs.getString("foodId");
			String foodName = rs.getString("foodName");
			Food food = new Food(foodId, foodName);
			foods1.put(foodId, food);
		}
		return foods1;
	}
}
