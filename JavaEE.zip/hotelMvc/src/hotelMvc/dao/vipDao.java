package hotelMvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import hotelMvc.JDBCutils.JDBCutils;

public class vipDao {
	
	public String getDiscount(String vip) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String discount=null;
		String sql = "select * from vip where vipLevel=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, vip);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				discount = rs.getString("vipDiscount");
			}
			JDBCutils.close(conn,ps);
			return discount;
	}
}
