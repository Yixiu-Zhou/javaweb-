package hotelMvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import hotelMvc.JDBCutils.JDBCutils;
import hotelMvc.domain.Order;

public class orderDao {
	private Map<String,Order> orders = new HashMap<>();
	
	//添加订单
	public boolean addOrder(String orderName, String orderRoom, String orderVipLevel, String orderPrice, String vipDiscount, String orderId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "insert into `order` values(0,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, orderName);
			ps.setString(2, orderRoom);
			ps.setString(3, orderVipLevel);
			ps.setString(4, orderPrice);
			ps.setString(5, null);
			ps.setString(6, vipDiscount);
			ps.setString(7, orderId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	public boolean deleteOrder(int orderId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "delete from order where orderId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,orderId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	public boolean updateOrder(int orderId, String orderName, String orderRoom, String orderVipLevel, String orderPrice, String vipPrice, String vipDiscount, String orderFood) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "update order set orderName=?,orderRoom=?,orderVipLevel=?,orderPrice=?,vipPrice=?,vipDiscount=?,orderFood=? where orderId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, orderName);
			ps.setString(2, orderRoom);
			ps.setString(3, orderVipLevel);
			ps.setString(4, orderPrice);
			ps.setString(5, vipPrice);
			ps.setString(6, vipDiscount);
			ps.setString(7, orderFood);
			ps.setInt(8,orderId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	public Map<String, Order> getOrder() throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String sql = "select * from `order`";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			int orderId = rs.getInt("orderId");
			String Id = Integer.toString(orderId);
			String orderName = rs.getString("orderName");
			String orderRoom = rs.getString("orderRoom");
			String orderVipLevel = rs.getString("orderVipLevel");
			String orderPrice = rs.getString("orderPrice");
			String vipPrice = rs.getString("vipPrice");
			String vipDiscount = rs.getString("vipDiscount");
			String orderFood = rs.getString("orderFood");
			Order order = new Order(orderId, orderName, orderRoom, orderVipLevel, orderPrice, vipPrice, vipDiscount, orderFood);
			orders.put(Id, order);
	}
		JDBCutils.close(conn,ps);
		return orders;
}

}
