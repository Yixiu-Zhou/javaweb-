package hotelMvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import hotelMvc.domain.*;

import hotelMvc.JDBCutils.*;
import hotelMvc.domain.*;

public class roomDao {
	private Map<String,Room> rooms = new HashMap<>();
	
	//添加房间
	public boolean addRoom(String roomName, String roomPrice, String roomStatus, String roomNumber) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "insert into room values(0,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, roomName);
			ps.setString(2, roomPrice);
			ps.setString(3, roomStatus);
			ps.setString(4, roomNumber);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	
	//删除房间
	public boolean deleteRoom(int roomId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "delete from room where roomId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,roomId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	
	//修改房间信息
	public boolean updateRoom(int roomId, String roomName, String roomPrice, String roomStatus, String roomNumber) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		String sql = "update room set roomName=?,roomPrice=?,roomStatus=?,roomNumber=? where roomId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, roomName);
			ps.setString(2, roomPrice);
			ps.setString(3, roomStatus);
			ps.setString(4, roomNumber);
			ps.setInt(5,roomId);
			int rs = ps.executeUpdate();
			if(rs>0)
				result=true;
			JDBCutils.close(conn,ps);
			return result;
	}
	
	//获取房间列表
	public Map<String, Room> searchRoom() throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		Room searchroom = null;
		String sql = "select * from room";
		PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){		
				int roomId2 = rs.getInt("roomId");
				String roomId = Integer.toString(roomId2);
				String roomName = rs.getString("roomName");
				String roomPrice = rs.getString("roomPrice");
				String roomStatus = rs.getString("roomStatus");
				String roomNumber = rs.getString("roomNumber");
				Room room = new Room(roomId, roomName, roomPrice, roomStatus, roomNumber);
				rooms.put(roomId, room);
			}
			JDBCutils.close(conn,ps);
			return rooms; 
	}
	
	//预定房间
	public void orderRoom(String roomId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String sql = "update room set roomStatus=? where roomId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, "已入住");
		ps.setString(2, roomId);
		int rs = ps.executeUpdate();
		JDBCutils.close(conn,ps);
		
	}


	public Room getRoomInfo(String roomId) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
//		System.out.println(roomId);
		int id = Integer.parseInt(roomId);
		Room room = null;
		String sql = "select * from room where roomId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		System.out.println(rs);
		while(rs.next()) {
			int roomId2 = rs.getInt("roomId");
			String roomId1 = Integer.toString(roomId2);
			String roomName = rs.getString("roomName");
			String roomPrice = rs.getString("roomPrice");
			String roomStatus = rs.getString("roomStatus");
			String roomNumber = rs.getString("roomNumber");
			room = new Room(roomId1, roomName, roomPrice, roomStatus, roomNumber);
		}
		JDBCutils.close(conn,ps);
		return room;
	}
	
//	 public void orderRoom(String roomId) throws ClassNotFoundException, IOException, SQLException {
//		  Connection conn = JDBCutils.getConnection();
//		  String sql = "update room set roomStatus=?,roomNumber=? where roomId=?";
//		  PreparedStatement ps = conn.prepareStatement(sql);
//		  int roomNumber=0;
//		  ResultSet rs = ps.executeQuery();
//		  while(!rs.next()) {
//			   roomNumber = Integer.parseInt(rs.getString("roomNumber"));
//		  }
//		  if(roomNumber>0) {
//		   ps.setString(1, "已入住");
//		   ps.setString(2, Integer.toString(roomNumber-1));
//		   ps.setString(3, roomId);
//		   JDBCutils.close(conn,ps);
//		 }
//	 }
//		 public void cancelRoom(String roomId) throws ClassNotFoundException, IOException, SQLException {
//		  Connection conn = JDBCutils.getConnection();
//		  String sql = "update room set roomStatus=?,roomNumber=? where roomId=?";
//		  PreparedStatement ps = conn.prepareStatement(sql);
//		  ps.setString(1, "未入住");
//		  ps.setString(2, Integer.toString(roomNumber-1));
//		  ps.setString(3, roomId);
//		  int rs = ps.executeUpdate();
//		  System.out.println(rs);
//		 }
}
