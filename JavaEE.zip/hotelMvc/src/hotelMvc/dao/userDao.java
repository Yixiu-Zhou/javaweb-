package hotelMvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import hotelMvc.JDBCutils.JDBCutils;
import hotelMvc.domain.User;

public class userDao {
	
	public boolean addUser(String userName, String userSex, String userPassword, String userTelephone, String userVip, String userType) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String sql = "insert into user values(0,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, userPassword);
			ps.setString(3, userType);
			ps.setString(4, userSex);
			ps.setString(5, userTelephone);
			ps.setString(6, userVip);
			int rs = ps.executeUpdate();
			JDBCutils.close(conn,ps);
			if(rs>0)
				return true;
			else
				return false;
	}
	
	public boolean loginUser(String userName, String userPassword, String userType) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();

		boolean result = false;
		String sql = "select * from user where userName=? and userPassword= ? and userType=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userName);
		ps.setString(2, userPassword);
		ps.setString(3, userType);
		ResultSet rs = ps.executeQuery();
		if(rs.next())
			result= true;
		JDBCutils.close(conn,ps);
		return result;
	}
	
	public boolean userInfoUpdate(String userId, String userName, String userPassword, String userType, String userSex, String userTelephone) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		boolean result = false;
		int Id = Integer.parseInt(userId);
		String sql = "Update user set userName=?,userPassword=?,userType=?,userSex=?,userTelephone=? where userId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userName);
		ps.setString(2, userPassword);
		ps.setString(3, userType);
		ps.setString(4, userSex);
		ps.setString(5, userTelephone);
		ps.setInt(6, Id);
		int rs = ps.executeUpdate();
		System.out.println(rs);
		if(rs>0)
			result=true;
		JDBCutils.close(conn,ps);
		return result;
	}
	
	@SuppressWarnings("unused")
	public User getUserInfo(String userName, String userPassword, String userType) throws ClassNotFoundException, IOException, SQLException {
		Connection conn = JDBCutils.getConnection();
		String userIds = null;
		String userNames = null;
		String userPasswords;
		String userTypes = null;
		String userSex = null;
		String userTelephone = null;
		String userVip = null;
		String sql = "select * from user where userName=? and userPassword= ? and userType=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userName);
		ps.setString(2, userPassword);
		ps.setString(3, userType);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			userIds = Integer.toString(rs.getInt("userId"));
			userNames = rs.getString("userName");
			userPasswords = rs.getString("userPassword");
			userTypes = rs.getString("userType");
			userSex = rs.getString("userSex");
			userTelephone = rs.getString("userTelephone");
			userVip = rs.getString("userVip");
		}
		User user = new User(userIds,userNames,userPassword,userTypes,userSex,userTelephone,userVip);
		JDBCutils.close(conn,ps);
		return user;
	}
}
