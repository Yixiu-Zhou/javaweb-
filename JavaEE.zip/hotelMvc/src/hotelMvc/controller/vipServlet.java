package hotelMvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hotelMvc.domain.User;
import hotelMvc.service.loginService;

/**
 * Servlet implementation class vipServlet
 */
@WebServlet("/vipServlet")
public class vipServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public vipServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				request.setCharacterEncoding("UTF-8");
				String order=request.getParameter("cmd");
			
				
					//获取用户信息	
				 if("getUserVip".equals(order)) {
					 	User user = loginService.user;
					 	System.out.println(user.getUserVip());
						request.setAttribute("User",user);
					request.getRequestDispatcher("user-update.jsp").forward(request, response);
					
					
					
				 }else if(true){
					 
				 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
