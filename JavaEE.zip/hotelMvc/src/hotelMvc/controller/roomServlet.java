package hotelMvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hotelMvc.domain.Food;
import hotelMvc.domain.Room;
import hotelMvc.domain.User;
import hotelMvc.service.foodService;
import hotelMvc.service.loginService;
import hotelMvc.service.roomService;

/**
 * Servlet implementation class hotelServlet
 */
@WebServlet("/roomServlet")
public class roomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String num=null;
       

    public roomServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				request.setCharacterEncoding("UTF-8");
				String order=request.getParameter("cmd");
	
			//新增房间
		 if("addRoom".equals(order)) {
			 String roomName=request.getParameter("roomName");
			 String roomPrice=request.getParameter("roomPrice");
			 String roomStatus=request.getParameter("roomStatus");
			 String roomNumber=request.getParameter("roomNumber");
			  try {
				roomService.addRoom(roomName, roomPrice, roomStatus, roomNumber);
				Map<String, Room> room = roomService.searchRoom();
				request.setAttribute("rooms",room);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.getRequestDispatcher("manager.jsp").forward(request, response);
			
			
			//删除房间
		}else if("deleteRoom".equals(order)) {
			 String roomId = request.getParameter("roomId");
			 	try {
					roomService.deleteRoom(roomId);
					Map<String, Room> room = roomService.searchRoom();
					request.setAttribute("rooms",room);
				} catch (ClassNotFoundException | IOException | SQLException e) {
					e.printStackTrace();
				}
			 request.getRequestDispatcher("manager.jsp").forward(request, response);
			 
			 
			 //获取房间信息
		}else if("getRoomInfo".equals(order)) {
			String roomId = request.getParameter("roomId");
			try {
				Room room = roomService.getRoomInfo(roomId);
//				System.out.println(room);
				request.setAttribute("room",room);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.getRequestDispatcher("room-update.jsp").forward(request, response);
			
			
		}else if("pageTurn".equals(order)) {
			 num = request.getParameter("num");
			 if("1".equals(num)) {
				 request.setAttribute("root",num);
			request.getRequestDispatcher("FileList.jsp").forward(request, response);
			 }else {
				request.getRequestDispatcher("FileList2.jsp").forward(request, response);
			 }

			
			
			 //更新房间
		}else if("updateRoom".equals(order)) {
			String roomId = request.getParameter("roomId");
			String roomName = request.getParameter("roomName");
			String roomPrice = request.getParameter("roomPrice");
			String roomStatus = request.getParameter("roomStatus");
			String roomNumber = request.getParameter("roomNumber");
		 	try {
				roomService.updateRoom(roomId, roomName, roomPrice, roomStatus, roomNumber);
				
				//获取房间列表
				Map<String, Room> i = roomService.searchRoom();
				request.setAttribute("rooms",i);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				e.printStackTrace();
			}
		 	request.getRequestDispatcher("manager.jsp").forward(request, response);
		 	
		 	
		 	
		}else if("goback".equals(order)) {
				try {
					Map<String, Room> i = roomService.searchRoom();
					request.setAttribute("rooms",i);
					if("1".equals(num)) 	
						request.getRequestDispatcher("manager.jsp").forward(request, response);
					else
						request.getRequestDispatcher("user.jsp").forward(request, response);
				} catch (ClassNotFoundException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
			
		}else if("orderRoom".equals(order)) {
			String roomId = request.getParameter("roomId");
				try {
					//修改房间入住状态
					roomService.orderRoom(roomId);
					

					Room room = roomService.getRoomInfo(roomId);
					request.setAttribute("room",room);
					
					//获取房间列表
					Map<String, Room> i = roomService.searchRoom();
					request.setAttribute("rooms",i);
					
					//获取用户会员等级
					User user = loginService.user;
					String vip = user.getUserVip();
					request.setAttribute("Vip",vip);
					
					//获取会员等级对应的菜品列表
					Map<String, Food> foods = foodService.getFoodList(vip);
					request.setAttribute("foods",foods);
			request.getRequestDispatcher("reserve.jsp").forward(request, response);
				} catch (ClassNotFoundException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
