package hotelMvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hotelMvc.domain.Room;
import hotelMvc.domain.User;
import hotelMvc.service.loginService;
import hotelMvc.service.roomService;



/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public loginServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			String order=request.getParameter("cmd");
		
			
		//获取用户信息	
	 if("getUserInfo".equals(order)) {
		 	User user = loginService.user;
			request.setAttribute("User",user);
		request.getRequestDispatcher("user-update.jsp").forward(request, response);
		
		
		
		//修改个人信息
	}else if("userInfoUpdate".equals(order)) {
		String userId=request.getParameter("userId");
		String userName=request.getParameter("userName");
		String userSex=request.getParameter("userSex");
		String userPassword=request.getParameter("userPassword");
		String userTelephone=request.getParameter("userTelephone");
		String userVip=request.getParameter("userVip");
		String userType=request.getParameter("userType");
			try {
				loginService.userInfoUpdate(userId, userName, userPassword, userType, userSex, userTelephone);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		request.getRequestDispatcher("login.jsp").forward(request, response);
		
		
		
		//注册功能
	}else if("register".equals(order)) {
		String userName=request.getParameter("userName");
		String userSex=request.getParameter("userSex");
		String userPassword=request.getParameter("userPassword");
		String userTelephone=request.getParameter("userTelephone");
		String userVip=request.getParameter("userVip");
		String userType=request.getParameter("userType");
			try {
				boolean result = loginService.register(userName,userSex,userPassword,userTelephone,userVip,userType);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				e.printStackTrace();
			}
		request.getRequestDispatcher("success.jsp").forward(request, response);
		
		
		//登录功能
	}else if("login".equals(order)) {
		String userName=request.getParameter("userName");
		String userPassword=request.getParameter("userPassword");
		String userType=request.getParameter("userType");
		
		String checkCode = request.getParameter("checkCode");
		// 获取生成的验证码
		  HttpSession session = request.getSession();
		  // 方法返回的是Object，会影响使用，需要强转string类型
		  String checkCode_session = (String) session.getAttribute("checkCode_session");
		  
		  // 判断用户名、密码和验证码
		  // equals在做验证码的时候，不支持忽略大小写；equalsIgnoreCase支持忽略大小写
		  if(checkCode_session != null && checkCode_session.equalsIgnoreCase(checkCode)) {
			  
				try {
					boolean res = loginService.login(userName,userPassword,userType);
					String type = loginService.getUserInfo(userName, userPassword, userType);
					if(!res) {
						request.setAttribute("message", "用户名不存在或者密码错误");
						request.getRequestDispatcher("fail.jsp").forward(request, response);
					}else {
						if("1".equals(type)) {
							Map<String, Room> room = roomService.searchRoom();
							request.setAttribute("rooms",room);
							request.getRequestDispatcher("manager.jsp").forward(request, response);
						}else {
							Map<String, Room> room = roomService.searchRoom();
							request.setAttribute("rooms",room);
							request.getRequestDispatcher("user.jsp").forward(request, response);
						}
					}
				} catch (ClassNotFoundException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
		  } else {
		   // 存储提示信息
		   request.setAttribute("message", "验证码错误");
		   // 继续跳转到登录页面
		   request.getRequestDispatcher("fail.jsp").forward(request, response);
		  }
		
	}
	 
	 
	 
}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
