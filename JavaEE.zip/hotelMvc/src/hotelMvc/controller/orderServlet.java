package hotelMvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hotelMvc.domain.Food;
import hotelMvc.domain.Order;
import hotelMvc.domain.Room;
import hotelMvc.domain.User;
import hotelMvc.service.foodService;
import hotelMvc.service.loginService;
import hotelMvc.service.orderService;
import hotelMvc.service.roomService;
import hotelMvc.service.vipService;

/**
 * Servlet implementation class orderServlet
 */
@WebServlet("/orderServlet")
public class orderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String foodId=null;

    public orderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String order=request.getParameter("cmd");
		
		
		if("addOrder".equals(order)) {
			 	try {
				 	//查询vip折扣
				 	User user = loginService.user;
				 	String userName= user.getUserName();
				 	String vip = user.getUserVip();
					String discount = vipService.getDiscount(vip);
					System.out.println(userName);
					System.out.println(vip);
					System.out.println(discount);
					
					//获取预定房间的信息
				 	String roomId = roomService.roomID;
				 	Room i = roomService.getRoomInfo(roomId);
				 	String roomName = i.getRoomName();
				 	String roomPrice = i.getRoomPrice();
				 	System.out.println(roomId);
				 	System.out.println(roomName);
				 	System.out.println(roomPrice);
				 	System.out.println(foodId);
					
				 	//获取酒店列表
				 	Map<String, Room> room = roomService.searchRoom();
				 	request.setAttribute("rooms",room);
				 	
				 	//增加订单
				 	orderService.addOrder(userName,vip,discount,roomId,roomName,roomPrice,foodId);
				 	
				} catch (ClassNotFoundException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
			request.getRequestDispatcher("user.jsp").forward(request, response);
			
		 }else if("addFood".equals(order)){
				try {
				//获取用户会员等级
				User user = loginService.user;
				String vip = user.getUserVip();
				request.setAttribute("Vip",vip);
				
				//获取会员等级对应的菜品列表
				Map<String, Food> foods;
				foods = foodService.getFoodList(vip);		
				request.setAttribute("foods",foods);
				
				String roomId = request.getParameter("roomId");
				Room room = roomService.getRoomInfo(roomId);
				request.setAttribute("room",room);
					 
			 	//获取食物的Id
			 	foodId=request.getParameter("foodId");
				} catch (ClassNotFoundException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		 	request.getRequestDispatcher("reserve.jsp").forward(request, response);
		 	
		 	
		 	//展示菜品列表
		 }else if("showOrder".equals(order)) {
			 try {
				Map<String, Order> orders = orderService.getOrderList();
				request.setAttribute("orders",orders);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
		 }
			request.getRequestDispatcher("reserve-info.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
