package hotelMvc.JDBCutils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCutils {
	public static Connection getConnection() throws IOException, ClassNotFoundException, SQLException {
		String url = "jdbc:mysql://localhost:3306/hotel?useUnicode=true&characterEncoding=utf8";
		String user = "root";
		String password = "root";
		Connection conn = null;

		Class.forName("com.mysql.jdbc.Driver");

		conn = DriverManager.getConnection(url,user,password);
		
		return conn;
	}
	public static void close(Connection conn, PreparedStatement ps){
		try{
			if(conn != null){
				conn.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		try{
			if(ps != null){
				ps.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
