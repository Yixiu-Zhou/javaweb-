package hotelMvc.JDBCutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

//import org.apache.commons.fileupload.FileItemFactory;
//import org.apache.commons.fileupload.disk.DiskFileItemFactory;
//import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class FileServlet
 */
@WebServlet("/FileServlet")
public class FileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String method = req.getParameter("method");
		 if ("upload".equals(method)) {
		 upload(req, resp);
		 } else if ("download".equals(method)) {
		 download(req, resp);
		 } else if ("delete".equals(method)) {
		 delete(req, resp);
		 } else {
		 getFileList(req, resp);
		 }
	}
	
	public void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
			 // 获取文件名
			 String fileName = req.getParameter("FileName");
			 // 获取文件目录
			 String path = this.getServletContext().getRealPath("/upload");
			 
			 File file = new File(path,fileName);
			 file.delete();
			 
			 // 删除文件之后，在页面中应该是消失的，调用获取文件列表的函数即可。
			 getFileList(req, resp);
			 
			 System.out.println(fileName);
	}
	
	@SuppressWarnings("static-access")
	public void upload(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 设置中文编码，防止中文文件名出现乱码（表单提交的中文文件名存在post提交数据中，所以可以使用这个方法来设置编码）
		req.setCharacterEncoding("utf-8");

		// 1. 创建文件上传工具类
		FileItemFactory fac = new DiskFileItemFactory();

		// 2. 创建文件上传核心类对象
		ServletFileUpload upload = new ServletFileUpload(fac);

		// 选择ServletFileUpload
		if (upload.isMultipartContent(req)) {
			try {
				// 3. 把请求数据转换为FileItem对象的集合
				List<FileItem> list = upload.parseRequest(req);

				for (FileItem item : list) {
					if (!item.isFormField()) {
						// 获取上传的文件名
						String fileName = item.getName();

						// 获取文件在上传时的存放路径
						String path = this.getServletContext().getRealPath("/upload");
	
						// 通过File对象，把path、fileName封装起来。
						// java.io.File.File
						File file = new File(path, fileName);
						item.write(file);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("上传异常");
			}
		}
		getFileList(req, resp);
	}

	// 获取文件列表
	public void getFileList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 文件所在路径
		String path = this.getServletContext().getRealPath("/upload");
		
		// 文件对象
		File file = new File(path);
		// 一个路径下的内容必然是有多个的文件的，所以把文件列表存在一个String数组中
		String[] list = file.list();

		req.setAttribute("FileList", list);
		 String num = req.getParameter("num");
		 if("2".equals(num))
		// 将文件列表传给前端的JSP页面。
			 req.getRequestDispatcher("/FileList2.jsp").forward(req, resp);
			 req.getRequestDispatcher("/FileList.jsp").forward(req, resp);
	}
	
	public void download(HttpServletRequest req, HttpServletResponse 
			resp) throws IOException {
			 // 获取用户下载的文件名
			 String fileName = req.getParameter("FileName");
			 System.out.println(fileName);
			 String path = this.getServletContext().getRealPath("/upload");
			 File file = new File(path, fileName);
			 FileInputStream in = new FileInputStream(file);
			 // 文件名中存在中文时，设置响应头编码
			 fileName = new String(fileName.getBytes("utf-8"), "iso-8859-1");
			 // 设置下载的响应头
			 resp.setHeader("content-disposition", "attachment;fileName=" +fileName);
			 // 获取response字节流
			 OutputStream out = resp.getOutputStream();
			 byte[] b = new byte[1024];
			 int len = -1;
			 while ((len = in.read(b)) != -1) {
				 out.write(b, 0, len);
			 }
			 out.close();
			 in.close();
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
