package hotelMvc.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import hotelMvc.dao.orderDao;
import hotelMvc.domain.Order;

public class orderService {

	public static void addOrder(String userName, String vip, String discount, String roomId, String roomName,
			String roomPrice, String foodId) throws ClassNotFoundException, IOException, SQLException {
		
		
		orderDao aaa = new orderDao();
		aaa.addOrder(userName, roomName, vip, roomPrice, discount,foodId);
		
	}

	public static Map<String, Order> getOrderList() throws ClassNotFoundException, IOException, SQLException {
		orderDao aaa = new orderDao();
		Map<String, Order> orders = aaa.getOrder();
		return orders;
	}
	
}
