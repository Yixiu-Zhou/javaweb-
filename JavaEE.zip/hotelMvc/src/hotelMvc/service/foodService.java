package hotelMvc.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import hotelMvc.dao.foodDao;
import hotelMvc.domain.Food;

public class foodService {

	public static Map<String, Food> getFoodList(String vip) throws ClassNotFoundException, IOException, SQLException {
		foodDao aaa =  new foodDao();
		Map<String, Food> i = aaa.getFoodList(vip);
		return i;
	}
	
}
