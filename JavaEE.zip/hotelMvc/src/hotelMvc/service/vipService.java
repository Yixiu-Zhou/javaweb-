package hotelMvc.service;

import java.io.IOException;
import java.sql.SQLException;

import hotelMvc.dao.vipDao;

public class vipService {

	public static String getDiscount(String vip) throws ClassNotFoundException, IOException, SQLException {
		vipDao aaa = new vipDao();
		String res =aaa.getDiscount(vip);
		return res;
	}
	
}
