package hotelMvc.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import hotelMvc.dao.roomDao;
import hotelMvc.domain.Room;

public class roomService {
	public static String roomID;
	
	static public void addRoom(String roomName, String roomPrice, String roomStatus, String roomNumber) throws ClassNotFoundException, IOException, SQLException {
			roomDao aaa =  new roomDao();
			aaa.addRoom(roomName, roomPrice, roomStatus, roomNumber);
	}

	public static void deleteRoom(String roomId) throws ClassNotFoundException, IOException, SQLException {
			int Id = Integer.parseInt(roomId);
			roomDao aaa =  new roomDao();
			aaa.deleteRoom(Id);
		
	}

	public static void updateRoom(String roomId, String roomName, String roomPrice, String roomStatus, String roomNumber) throws ClassNotFoundException, IOException, SQLException {
		int Id = Integer.parseInt(roomId);
		roomDao aaa =  new roomDao();
		aaa.updateRoom(Id, roomName, roomPrice, roomStatus, roomNumber);
		
	}

	public static Map<String, Room> searchRoom() throws ClassNotFoundException, IOException, SQLException {
		roomDao aaa =  new roomDao();
		Map<String, Room> res = aaa.searchRoom();
		return res;
	}

	public static void orderRoom(String roomId) throws ClassNotFoundException, IOException, SQLException {
		roomDao aaa =  new roomDao();
		aaa.orderRoom(roomId);
		
	}

	public static Room getRoomInfo(String roomId) throws ClassNotFoundException, IOException, SQLException {
		roomID=roomId;
		roomDao aaa =  new roomDao();
		Room room = aaa.getRoomInfo(roomId);
		return room;
	}
}
