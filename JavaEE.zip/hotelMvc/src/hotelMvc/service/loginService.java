package hotelMvc.service;

import java.io.IOException;
import java.sql.SQLException;

import hotelMvc.dao.userDao;
import hotelMvc.domain.User;

public class loginService {
	public static User user=null;
	
	
	static public boolean register(String userName, String userSex, String userPassword, String userTelephone, String userVip, String userType) throws ClassNotFoundException, IOException, SQLException {
			userDao aaa = new userDao();
			boolean res = aaa.addUser(userName,userSex,userPassword,userTelephone,userVip,userType);
		return res;
		
	}

	public static boolean login(String userName, String userPassword, String userType) throws ClassNotFoundException, IOException, SQLException {
			userDao aaa = new userDao();
			boolean res = aaa.loginUser(userName,userPassword,userType);
			 return res;
	}

	public static void userInfoUpdate(String userId, String userName, String userPassword, String userType, String userSex, String userTelephone) throws ClassNotFoundException, IOException, SQLException {
		userDao aaa = new userDao();
		boolean res = aaa.userInfoUpdate(userId, userName, userPassword, userType, userSex, userTelephone);
	}

	public static String getUserInfo(String userName, String userPassword, String userType) throws ClassNotFoundException, IOException, SQLException {
		userDao aaa = new userDao();
		 user = aaa.getUserInfo(userName, userPassword, userType);
				String type = user.getUserType();
		return type;
	
	}
}
