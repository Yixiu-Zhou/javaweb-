package hotelMvc.domain;

public class Food {
	private String foodId;
	private String foodName;
	private String foodVip;
	
	
	public String getFoodId() {
		return foodId;
	}


	public void setFoodId(String foodId) {
		this.foodId = foodId;
	}


	public String getFoodName() {
		return foodName;
	}


	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}


	public String getFoodVip() {
		return foodVip;
	}


	public void setFoodVip(String foodVip) {
		this.foodVip = foodVip;
	}


	public Food(String foodId, String foodName, String foodVip) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.foodVip = foodVip;
	}


	public Food(String foodId, String foodName) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
	}
	
	
}
