package hotelMvc.domain;

public class Order {
	private int orderId;
	private String orderName;
	private String orderRoom;
	private String orderVipLevel;
	private String orderPrice;
	private String vipPrice;
	private String vipDiscount;
	private String orderFood;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public String getOrderRoom() {
		return orderRoom;
	}
	public void setOrderRoom(String orderRoom) {
		this.orderRoom = orderRoom;
	}
	public String getOrderVipLevel() {
		return orderVipLevel;
	}
	public void setOrderVipLevel(String orderVipLevel) {
		this.orderVipLevel = orderVipLevel;
	}
	public String getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(String orderPrice) {
		this.orderPrice = orderPrice;
	}
	public String getVipPrice() {
		return vipPrice;
	}
	public void setVipPrice(String vipPrice) {
		this.vipPrice = vipPrice;
	}
	public String getVipDiscount() {
		return vipDiscount;
	}
	public void setVipDiscount(String vipDiscount) {
		this.vipDiscount = vipDiscount;
	}
	public String getOrderFood() {
		return orderFood;
	}
	public void setOrderFood(String orderFood) {
		this.orderFood = orderFood;
	}
	public Order(int orderId, String orderName, String orderRoom, String orderVipLevel, String orderPrice,
			String vipPrice, String vipDiscount, String orderFood) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderRoom = orderRoom;
		this.orderVipLevel = orderVipLevel;
		this.orderPrice = orderPrice;
		this.vipPrice = vipPrice;
		this.vipDiscount = vipDiscount;
		this.orderFood = orderFood;
	}
	
	
}
