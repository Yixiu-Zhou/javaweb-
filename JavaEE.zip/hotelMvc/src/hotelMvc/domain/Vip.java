package hotelMvc.domain;

public class Vip {
	private String vipName;
	private String vipLevel;
	private String vipDiscount;
	
}
