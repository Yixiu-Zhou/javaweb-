package hotelMvc.domain;

public class Room {
	private String roomId;
	private String roomName;
	private String roomPrice;
	private String roomStatus;
	private String roomNumber;
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomPrice() {
		return roomPrice;
	}
	public void setRoomPrice(String roomPrice) {
		this.roomPrice = roomPrice;
	}
	public String getRoomStatus() {
		return roomStatus;
	}
	public void setRoomStatus(String roomStatus) {
		this.roomStatus = roomStatus;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public Room(String roomId, String roomName, String roomPrice, String roomStatus, String roomNumber) {
		super();
		this.roomId = roomId;
		this.roomName = roomName;
		this.roomPrice = roomPrice;
		this.roomStatus = roomStatus;
		this.roomNumber = roomNumber;
	}


	
}
