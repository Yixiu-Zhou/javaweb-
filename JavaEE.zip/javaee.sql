/*
Navicat MySQL Data Transfer

Source Server         : javaee大作业
Source Server Version : 50650
Source Host           : 49.232.154.162:3306
Source Database       : javaee

Target Server Type    : MYSQL
Target Server Version : 50650
File Encoding         : 65001

Date: 2022-06-20 15:59:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `food`
-- ----------------------------
DROP TABLE IF EXISTS `food`;
CREATE TABLE `food` (
  `foodId` int(11) NOT NULL AUTO_INCREMENT,
  `foodName` varchar(255) NOT NULL,
  `foodVip` varchar(255) NOT NULL,
  PRIMARY KEY (`foodId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of food
-- ----------------------------
INSERT INTO `food` VALUES ('1', '玉带虾仁', '1');
INSERT INTO `food` VALUES ('2', '辣子鸡丁', '1');
INSERT INTO `food` VALUES ('3', '凉豆腐', '1');
INSERT INTO `food` VALUES ('4', '叫花鸡', '1');
INSERT INTO `food` VALUES ('5', '醉排骨', '1');
INSERT INTO `food` VALUES ('6', '酸辣土豆丝', '1');
INSERT INTO `food` VALUES ('7', '东坡肘子', '2');
INSERT INTO `food` VALUES ('8', '酸菜鱼', '2');
INSERT INTO `food` VALUES ('9', '红扒鱼翅', '2');
INSERT INTO `food` VALUES ('10', '口袋豆腐', '2');
INSERT INTO `food` VALUES ('11', '龙身凤尾虾', '3');
INSERT INTO `food` VALUES ('12', '七星鱼丸汤', '3');
INSERT INTO `food` VALUES ('13', '地三鲜', '2');
INSERT INTO `food` VALUES ('14', '麻婆豆腐', '3');
INSERT INTO `food` VALUES ('15', '鱼香肉丝', '3');
INSERT INTO `food` VALUES ('16', '油爆双脆', '2');

-- ----------------------------
-- Table structure for `order`
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `orderName` varchar(255) NOT NULL,
  `orderRoom` varchar(255) NOT NULL,
  `orderVipLevel` varchar(255) NOT NULL,
  `orderPrice` varchar(255) NOT NULL,
  `vipPrice` varchar(255) DEFAULT NULL,
  `vipDiscount` varchar(255) NOT NULL,
  `orderFood` varchar(255) NOT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', 'user', '豪华套间', '3', '1888', null, '0.65', '11');

-- ----------------------------
-- Table structure for `room`
-- ----------------------------
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `roomId` int(11) NOT NULL AUTO_INCREMENT,
  `roomName` varchar(255) NOT NULL,
  `roomPrice` varchar(255) NOT NULL,
  `roomStatus` varchar(255) NOT NULL,
  `roomNumber` varchar(255) NOT NULL,
  PRIMARY KEY (`roomId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of room
-- ----------------------------
INSERT INTO `room` VALUES ('1', '豪华套间', '1888', '已入住', '2');
INSERT INTO `room` VALUES ('2', '标准间', '588', '未入住', '5');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userType` varchar(255) NOT NULL,
  `userSex` varchar(255) DEFAULT NULL,
  `userTelephone` varchar(255) DEFAULT NULL,
  `userVip` varchar(255) DEFAULT NULL,
  `isYuding` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '666', '1', '男', '799', '0', '');
INSERT INTO `user` VALUES ('2', 'user', '666', '2', '女', '9997', '3', '1');
INSERT INTO `user` VALUES ('3', '22', '22', '1', '男', '22', '0', '');
INSERT INTO `user` VALUES ('4', '222', '222', '1', null, null, null, null);
INSERT INTO `user` VALUES ('5', '333', '333', '2', null, null, null, '66');
INSERT INTO `user` VALUES ('6', '2222', '123', '1', null, null, null, null);
INSERT INTO `user` VALUES ('7', '222', '123', '1', null, null, null, null);
INSERT INTO `user` VALUES ('8', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('9', '1', '555', '1', null, null, null, '6');
INSERT INTO `user` VALUES ('10', '222', '222', '1', null, null, null, null);
INSERT INTO `user` VALUES ('11', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('12', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('13', '111', '1', '2', null, null, null, null);
INSERT INTO `user` VALUES ('14', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('15', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('16', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('17', '111', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('18', 'aaa', 'aaa', '1', null, null, null, null);
INSERT INTO `user` VALUES ('19', '123', '123', '1', null, null, null, null);
INSERT INTO `user` VALUES ('20', '456', '456', '2', null, null, null, null);
INSERT INTO `user` VALUES ('21', '233', '233', '1', null, null, null, null);
INSERT INTO `user` VALUES ('22', '244', '244', '1', null, null, null, null);
INSERT INTO `user` VALUES ('23', '255', '255', '1', null, null, null, null);
INSERT INTO `user` VALUES ('24', '444', '444', '1', null, null, null, 'hhh');
INSERT INTO `user` VALUES ('25', '666', '666', '2', null, null, null, null);
INSERT INTO `user` VALUES ('26', '444', '444', '2', null, null, null, 'hhh');
INSERT INTO `user` VALUES ('27', '333', '333', '2', null, null, null, null);
INSERT INTO `user` VALUES ('28', 'lyb', '111', '1', null, null, null, '6');
INSERT INTO `user` VALUES ('29', 'sjm', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('30', 'yzh', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('35', 'sjm', '111', '1', null, null, null, null);
INSERT INTO `user` VALUES ('36', 'lyb', '222', '2', null, null, null, '6');

-- ----------------------------
-- Table structure for `vip`
-- ----------------------------
DROP TABLE IF EXISTS `vip`;
CREATE TABLE `vip` (
  `vipName` varchar(255) NOT NULL,
  `vipLevel` varchar(255) NOT NULL,
  `vipDiscount` varchar(255) NOT NULL,
  PRIMARY KEY (`vipName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of vip
-- ----------------------------
INSERT INTO `vip` VALUES ('钻石会员', '2', '0.8');
INSERT INTO `vip` VALUES ('黄金会员', '1', '0.9');
INSERT INTO `vip` VALUES ('黑金会员', '3', '0.65');
